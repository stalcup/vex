package vex;

public class Vex {
  public static Platform platform;
}
