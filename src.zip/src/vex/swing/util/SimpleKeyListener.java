package vex.swing.util;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class SimpleKeyListener implements KeyListener {

  @Override
  public void keyPressed(KeyEvent e) {}

  @Override
  public void keyReleased(KeyEvent e) {}

  @Override
  public void keyTyped(KeyEvent e) {}
}
